# Replication package — SFTR-D-26-03205 (revised)

Reproduces every number, table, and figure in the revised manuscript and Supplementary Material.
Python 3.9+ with numpy, scipy, pandas, openpyxl, shapely, matplotlib.

## Data
- `papi_source_ledger.csv`, `papi_indicator_ledger_2018_2022.csv`: one row per value, with source file, worksheet, cell, row label, and SHA-256 of the file (PAPI workbooks, CECODES/VFF-CRT/RTA/UNDP).
- `papi_panel_63_2011_2022.csv`, `papi_indicators_63_2018_2022.csv`: panels built from the ledgers (no imputation; blank where PAPI publishes no score).
- `pci_panel_63x11_SOURCE_EXTRACTED.csv` (VCCI PCI), `gso_population_urban_63x8_SOURCE_EXTRACTED.csv` (GSO yearbook), `province_crosswalk_63.csv`.
- `centroids_63_naturalearth.csv`, `contiguity_63_naturalearth.csv`: built from Natural Earth 1:10m admin-1 polygons (source URL and SHA-256 in the centroid file).
- `gso_waste_wide_from_upload.csv`: GSO yearbook waste statistics used only for validation (2020 values flagged; see Supplementary Material S5).

## Run order
1. `extract_papi.py <PAPI dir> <out> <crosswalk>` (dimension scores 2011-2022) and `extract_indicators_2024.py <PAPI dir> out24 <crosswalk>` (indicators 2018-2024; `extract_indicators.py` is the earlier 2018-2022 version, whose values it reproduces exactly). Requires the original PAPI workbooks.
2. `build_weights_ne.py ne_10m_admin_1_states_provinces.geojson <crosswalk> <out>`.
3. `revision_analysis.py` → `results.json` (all estimates; fixed seeds).
4. `make_fig2.py` → Figure 2 (asserts that the bins sum to N and to the regime totals).
5. `validate_gso.py`, `validate_external.py` → validation correlations.
Paths at the top of each script point to the data folder and may need adjusting.
